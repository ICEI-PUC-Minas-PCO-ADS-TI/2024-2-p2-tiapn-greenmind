# Introdução
Este artefato tem o objetivo de informar as pessoas o gasto excessivo de recursos naturais que fazemos no cotidiano.<br>
Fazemos isso através da `Pegada Ecológica`. 

<br>
<hr>
<br>

## O que é uma Pegada Ecológica? 🍀
É uma pesquisa onde você pode verificar o quanto você gasta do planeta.

<br>
<hr>
<br>

## Como saber se eu tenho gastos excessivos? :eyes:
Simples, quanto maior for a sua pontuação,<br>menos você gasta dos recursos naturais e melhor é a sua consciência ambiental.

<br>
<hr>
<br>

## Acesso ao Projeto :file_folder:
Acesse nosso site: <a href="https:\\" >Clique Aqui</a> 

<br>
<hr>
<br>
<br>

### Telas no Figma

#### Landing Page
<a href="https://www.figma.com/design/EYfykzn72BVDNQFwjevTCi/Untitled?node-id=0-1&m=dev&t=rYBEw5UOrRd3TAjd-1">Versão Inicial</a>
<br>

<br>
<hr>
